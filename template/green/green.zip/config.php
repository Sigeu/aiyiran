<?php return array (
  'name' => '绿色分类信息站模板',
  'author' => 'MOCMS TEAM',
  'identify' => 'green',
  'homepage' => 'http://b2b.cms.cn/',
  'version' => '1.0',
  'disable' => 1,
  'file' => 
  array (
    'banner.html' => 
    array (
      'describe' => '头文件下面的搜索栏',
      'system' => '0',
    ),
    'category.html' => 
    array (
      'describe' => '左侧导航',
      'system' => '0',
    ),
    'content_chwl.html' => 
    array (
      'describe' => '内容页—吃喝玩乐',
      'system' => '0',
    ),
    'content_shmz.html' => 
    array (
      'describe' => '内容页—生活妙招',
      'system' => '0',
    ),
    'content_xwjh.html' => 
    array (
      'describe' => '内容页—闲物交换',
      'system' => '0',
    ),
    'footer.html' => 
    array (
      'describe' => '底文件',
      'system' => '',
    ),
    'head.html' => 
    array (
      'describe' => '头文件',
      'system' => '',
    ),
    'index.html' => 
    array (
      'describe' => '首页',
      'system' => '1',
    ),
    'index_bj.html' => 
    array (
      'describe' => '栏目首页—北京新闻',
      'system' => '',
    ),
    'index_chwl.html' => 
    array (
      'describe' => '栏目首页—吃喝玩乐',
      'system' => '0',
    ),
    'index_shmz.html' => 
    array (
      'describe' => '栏目首页—生活妙招',
      'system' => '0',
    ),
    'index_xwjh.html' => 
    array (
      'describe' => '栏目首页—闲物交换',
      'system' => '0',
    ),
    'index_zcfc.html' => 
    array (
      'describe' => '栏目首页—政策法则',
      'system' => '0',
    ),
    'list_bj.html' => 
    array (
      'describe' => '栏目首页—北京新闻',
      'system' => '0',
    ),
    'list_chwl.html' => 
    array (
      'describe' => '列表页—吃喝玩乐',
      'system' => '0',
    ),
    'list_shmz.html' => 
    array (
      'describe' => '列表页—生活妙招',
      'system' => '0',
    ),
    'list_xwjh.html' => 
    array (
      'describe' => '列表页—闲物交换',
      'system' => '0',
    ),
    'list_zcfc.html' => 
    array (
      'describe' => '列表页—政策法则',
      'system' => '0',
    ),
    'login.html' => 
    array (
      'describe' => '登陆页面',
      'system' => '0',
    ),
    'message.html' => 
    array (
      'describe' => '留言板',
      'system' => '0',
    ),
    'qq.html' => 
    array (
      'describe' => '',
      'system' => 0,
    ),
    'register.html' => 
    array (
      'describe' => '注册页面',
      'system' => '0',
    ),
    'shmz.html' => 
    array (
      'describe' => '333',
      'system' => '0',
    ),
    'tophead.html' => 
    array (
      'describe' => '头部登录',
      'system' => '0',
    ),
  ),
  'describe' => '默认模板',
  'image' => '{E422CF7B-737B-55AC-9711-C3B779DCAD59}.jpg',
);?>