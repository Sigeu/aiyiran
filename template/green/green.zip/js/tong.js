 function init()
 {
	 $.formValidator.initConfig({
		autotip:true,
		formid:"messageForm",
		debug:false,
		onError:function(msg){},
		onSuccess:function() {}
	});
 }
   