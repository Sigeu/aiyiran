<?php return array (
  'name' => '蓝色商业资讯网模版',
  'author' => 'MOCMS TEAM',
  'identify' => 'default',
  'homepage' => 'http://cms.b2b.cn/',
  'version' => '1.0',
  'disable' => 1,
  'file' =>
  array (
    'banner.html' =>
    array (
      'describe' => '头文件下面的搜索栏',
      'system' => '0',
    ),
    'category.html' =>
    array (
      'describe' => '左侧导航',
      'system' => '0',
    ),
    'content_chwl.html' =>
    array (
      'describe' => '内容页—吃喝玩乐',
      'system' => '0',
    ),
    'content_shmz.html' =>
    array (
      'describe' => '内容页—生活妙招',
      'system' => '0',
    ),
    'content_xwjh.html' =>
    array (
      'describe' => '内容页—闲物交换',
      'system' => '0',
    ),
    'footer.html' =>
    array (
      'describe' => '底文件',
      'system' => '',
    ),
    'head.html' =>
    array (
      'describe' => '头文件',
      'system' => '',
    ),
    'index.html' =>
    array (
      'describe' => '首页',
      'system' => '1',
    ),
    'index_bj.html' =>
    array (
      'describe' => '栏目首页—北京新闻',
      'system' => '',
    ),
    'index_chwl.html' =>
    array (
      'describe' => '栏目首页—吃喝玩乐',
      'system' => '0',
    ),
    'index_shmz.html' =>
    array (
      'describe' => '栏目首页—生活妙招',
      'system' => '0',
    ),
    'index_xwjh.html' =>
    array (
      'describe' => '栏目首页—闲物交换',
      'system' => '0',
    ),
    'index_zcfc.html' =>
    array (
      'describe' => '栏目首页—政策法则',
      'system' => '0',
    ),
    'list_bj.html' =>
    array (
      'describe' => '栏目首页—北京新闻',
      'system' => '0',
    ),
    'list_chwl.html' =>
    array (
      'describe' => '列表页—吃喝玩乐',
      'system' => '0',
    ),
    'list_shmz.html' =>
    array (
      'describe' => '列表页—生活妙招',
      'system' => '0',
    ),
    'list_xwjh.html' =>
    array (
      'describe' => '列表页—闲物交换',
      'system' => '0',
    ),
    'list_zcfc.html' =>
    array (
      'describe' => '列表页—政策法则',
      'system' => '0',
    ),
    'login.html' =>
    array (
      'describe' => '登陆页面',
      'system' => '0',
    ),
    'message.html' =>
    array (
      'describe' => '内容页-意见和建议',
      'system' => '0',
    ),
    'register.html' =>
    array (
      'describe' => '注册页面',
      'system' => '0',
    ),
    'shmz.html' =>
    array (
      'describe' => '',
      'system' => 0,
    ),
    'tophead.html' =>
    array (
      'describe' => '头部登录',
      'system' => '0',
    ),
    'index_map.html' =>
    array (
      'describe' => '网站地图',
      'system' => '',
    ),
    'registerdeal.html' =>
    array (
      'describe' => '注册协议',
      'system' => '',
    ),
    'content_detail.html' =>
    array (
      'describe' => '内容页-详细页面',
      'system' => '',
    ),
    'index_sj.html' =>
    array (
      'describe' => '栏目页-商界',
      'system' => '',
    ),
    'index_eco.html' =>
    array (
      'describe' => '栏目页-经济',
      'system' => '',
    ),
    'index_sh.html' =>
    array (
      'describe' => '栏目页-社会生活',
      'system' => '',
    ),
    'index_xf.html' =>
    array (
      'describe' => '栏目页-消费',
      'system' => '',
    ),
    'index_kj.html' =>
    array (
      'describe' => '栏目页-科技',
      'system' => '',
    ),
    'index_sy.html' =>
    array (
      'describe' => '栏目页-商业',
      'system' => '',
    ),
    'list_news.html' =>
    array (
      'describe' => '列表页-文章',
      'system' => '',
    ),
    'index_sd.html' =>
    array (
      'describe' => '栏目页-商道',
      'system' => '',
    ),
    'thumb.html' =>
    array (
      'describe' => '面包屑',
      'system' => '',
    ),
    'search.html' =>
    array (
      'describe' => '列表页-搜索结果',
      'system' => '',
    ),
    'content_comp.html' =>
    array (
      'describe' => '内容页-关于我们',
      'system' => '',
    ),
    'friendlink.html' =>
    array (
      'describe' => '友情链接',
      'system' => '',
    ),
  ),
  'describe' => '默认模板',
  'image' => 'default.jpg',
);?>