<?php return array (
  'name' => '绿色分类信息站模板2',
  'author' => 'MOCMS TEAM',
  'identify' => 'green2',
  'homepage' => 'http://localhost/',
  'version' => '1.0',
  'disable' => 1,
  'file' => 
  array (
    'content_chwl.html' => 
    array (
      'describe' => '内容页—吃喝玩乐',
      'system' => '0',
    ),
    'index.html' => 
    array (
      'describe' => '首页',
      'system' => '1',
    ),
    'head.html' => 
    array (
      'describe' => '头文件',
      'system' => '',
    ),
    'content_shmz.html' => 
    array (
      'describe' => '内容页—生活妙招',
      'system' => '0',
    ),
    'content_xwjh.html' => 
    array (
      'describe' => '内容页—闲物交换',
      'system' => '0',
    ),
    'search.html' => 
    array (
      'describe' => '',
      'system' => 0,
    ),
    'footer.html' => 
    array (
      'describe' => '底文件',
      'system' => '',
    ),
    'banner.html' => 
    array (
      'describe' => '头文件下面的搜索栏',
      'system' => '0',
    ),
    'index_bj.html' => 
    array (
      'describe' => '栏目首页—北京新闻',
      'system' => '',
    ),
    'category.html' => 
    array (
      'describe' => '产品分类',
      'system' => '0',
    ),
    'registerdeal.html' => 
    array (
      'describe' => '',
      'system' => 0,
    ),
    'message.html' => 
    array (
      'describe' => '留言板',
      'system' => '0',
    ),
    'chwl.html' => 
    array (
      'describe' => '',
      'system' => 0,
    ),
    'qq.html' => 
    array (
      'describe' => '',
      'system' => 0,
    ),
    'chwlDetail.html' => 
    array (
      'describe' => '',
      'system' => 0,
    ),
    'shmz.html' => 
    array (
      'describe' => '',
      'system' => 0,
    ),
    'registdeal.html' => 
    array (
      'describe' => '',
      'system' => 0,
    ),
    'register.html' => 
    array (
      'describe' => '注册页面',
      'system' => '0',
    ),
    'tophead.html' => 
    array (
      'describe' => '头部登录',
      'system' => '0',
    ),
    'login.html' => 
    array (
      'describe' => '登陆页面',
      'system' => '0',
    ),
    'list_shmz.html' => 
    array (
      'describe' => '列表页—生活妙招',
      'system' => '0',
    ),
    'list_chwl.html' => 
    array (
      'describe' => '列表页—吃喝玩乐',
      'system' => '0',
    ),
    'index_chwl.html' => 
    array (
      'describe' => '栏目首页—吃喝玩乐',
      'system' => '0',
    ),
    'list_bj.html' => 
    array (
      'describe' => '栏目首页—北京新闻',
      'system' => '0',
    ),
    'index_zcfc.html' => 
    array (
      'describe' => '栏目首页—政策法则',
      'system' => '0',
    ),
    'index_xwjh.html' => 
    array (
      'describe' => '栏目首页—闲物交换',
      'system' => '0',
    ),
    'index_shmz.html' => 
    array (
      'describe' => '栏目首页—生活妙招',
      'system' => '0',
    ),
    'list_zcfc.html' => 
    array (
      'describe' => '列表页—政策法则',
      'system' => '0',
    ),
    'list_xwjh.html' => 
    array (
      'describe' => '列表页—闲物交换',
      'system' => '0',
    ),
  ),
  'describe' => '默认模板',
  'image' => '{516B07A9-CF1C-552D-6BF0-93A429162527}.jpg',
);?>